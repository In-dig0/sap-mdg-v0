/* @bruin
name: stg.ck504_marc_a2f
type: pg.sql
depends:
  - stg.clean_check_results
description: >
  CK504 — CROSS_SOURCE: Materiali S_MARC devono essere presenti in A2F
  a parità di articolo (PRODUCT = CODART) e divisione (WERKS).
  Il mapping plant → tabella A2F è:
    WERKS = 'IT11' → ref.A2F_BO
    WERKS = 'IT12' → ref.A2F_FA
  I materiali con WERKS non mappato vengono ignorati (non generano errore).
  Le sorgenti appartengono ad archivi ZIP / sorgenti diversi.
connection: mdg_postgres
@bruin */

-- Esegui solo se il check è abilitato nel catalogo
DO $$ BEGIN
  IF NOT (
    SELECT COALESCE(is_active, FALSE)
    FROM stg.check_catalog
    WHERE check_id = 'CK504'
  ) THEN RETURN; END IF;
END $$;

INSERT INTO stg.check_results (
    source_table, category, object_key, check_id,
    message, status, run_id, zip_source, created_at
)

-- Plant IT11 → A2F_BO
SELECT
    'S_MARC'                                        AS source_table,
    'MAT'                                           AS category,
    marc."PRODUCT(k/*)"                             AS object_key,
    'CK504'                                         AS check_id,
    'Materiale [' || marc."PRODUCT(k/*)" || '] '
        || 'plant [IT11] '
        || 'non presente in ref.A2F_BO (CODART)'   AS message,
    'Error'                                         AS status,
    (SELECT run_id FROM stg.pipeline_runs
     WHERE status = 'running'
     ORDER BY started_at DESC LIMIT 1)              AS run_id,
    marc."_source"                                  AS zip_source,
    NOW()                                           AS created_at
FROM raw."S_MARC" marc
WHERE marc."WERKS(k/*)" = 'IT11'
  AND NOT EXISTS (
      SELECT 1 FROM ref."A2F_BO" a2f
      WHERE a2f."CODART" = marc."PRODUCT(k/*)"
  )

UNION ALL

-- Plant IT12 → A2F_FA
SELECT
    'S_MARC'                                        AS source_table,
    'MAT'                                           AS category,
    marc."PRODUCT(k/*)"                             AS object_key,
    'CK504'                                         AS check_id,
    'Materiale [' || marc."PRODUCT(k/*)" || '] '
        || 'plant [IT12] '
        || 'non presente in ref.A2F_FA (CODART)'   AS message,
    'Error'                                         AS status,
    (SELECT run_id FROM stg.pipeline_runs
     WHERE status = 'running'
     ORDER BY started_at DESC LIMIT 1)              AS run_id,
    marc."_source"                                  AS zip_source,
    NOW()                                           AS created_at
FROM raw."S_MARC" marc
WHERE marc."WERKS(k/*)" = 'IT12'
  AND NOT EXISTS (
      SELECT 1 FROM ref."A2F_FA" a2f
      WHERE a2f."CODART" = marc."PRODUCT(k/*)"
  )
;

